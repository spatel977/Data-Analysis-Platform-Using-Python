# The following libraries were used and are necessary to run the code:
-	Pandas
-	Numpy
-	PIL/Pillow
-	Matplotlib
-	Sklearn
-	Keras
-	Pydot
-	Seaborn
-	Scipy
-	Openpyxl
-	Tensorflow

# Master AIT Project
- Shail Patel	- 11148263
- Aashika Srinivas - 11148272
- Faaiz Ahmed	- 11148258

##  GUI (Graphical User Interface)

### Task: 
-   Application design
-   Source code development (except the codes in the folders mention by other groups)
-   General Code organization/refractoring and 
-   Code integration and testing.

##  Data Filtering and Smoothing
### Source Code Directory: analysis/data_preparation/


##  AI based models for Regression and Classification
### Source Code Directory: analysis/ai/


##  Regression and Classification
### Source Code Directory: analysis/classical/






